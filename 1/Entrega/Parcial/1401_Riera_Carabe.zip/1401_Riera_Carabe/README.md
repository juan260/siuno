Juan Riera y Luis Cárabe

Entrega parcial de la primera práctica de la asignatura SI 1.

Contenido:

*Capturas-DiseñoWeb: capturas de pantalla que representan la idea general de cómo se verá la página web en su diseño final.

*css: hoja de estilo css para los ficheros html.

*html: código html de la página web por el momento.

*imgs: recursos utilizados por los html (imágenes).

*Diagrama.png: mapa de navegación.


